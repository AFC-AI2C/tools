.. _misc:

**********************
Miscellaneous Services
**********************

The modules described in this chapter provide miscellaneous services that are
available in all Python versions.  Here's an overview:


.. toctree::

   formatter.rst
